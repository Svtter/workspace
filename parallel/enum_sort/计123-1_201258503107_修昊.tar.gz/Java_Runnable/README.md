加速比
---
![enum_sort.png](enum_sort.png)
- 加速比大概为1.9
