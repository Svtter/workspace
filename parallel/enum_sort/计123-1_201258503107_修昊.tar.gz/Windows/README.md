小注
===

- waitforMutipleobjects不是很好用，写了一个循环等所有的进程。

加速比
---
![enum_sort_win32.png](enum_sort_win32.png)
- 稳定在3.0左右
