小注
===

- 用了同步机制，wait函数不太好用（可能是我自己不打会用）

加速比
---
![enum_sort_MFC.png](enum_sort_MFC.png)
- 稳定在3.0左右
