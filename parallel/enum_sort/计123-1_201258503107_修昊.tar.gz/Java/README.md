小注：
===

- 使用`thread_join()`方法保证所有的线程都运行完毕。

并行加速比： 
---
![enum_sort.png](enum_sort.png)
- 接近2.4
