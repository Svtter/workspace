小注：
===

- 开始数据需要加锁保证

加速比：
---
![pic](enum_sort_Csharp.png)
稳定在2.4左右
